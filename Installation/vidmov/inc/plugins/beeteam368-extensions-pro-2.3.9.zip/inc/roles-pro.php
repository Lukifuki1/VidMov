<?php
/**
 * BeeTeam368 Extensions Pro Roles
 */

if (!class_exists('beeteam368_roles_pro')) {
    class beeteam368_roles_pro
    {
        public function __construct()
        {
            $this->capabilities_hook();
        }

        private function capabilities_hook()
        {
            add_filter('beeteam368_capabilities', function ($capabilities) {
                $capabilities[] = BEETEAM368_PREFIX . '_youtube_import_settings';
                $capabilities[] = BEETEAM368_PREFIX . '_vimeo_import_settings';
                $capabilities[] = BEETEAM368_PREFIX . '_user_submit_post_settings';
                                $capabilities[] = BEETEAM368_PREFIX . '_ffmpeg_control_settings';
                                $capabilities[] = BEETEAM368_PREFIX . '_bunny_cdn_settings';
                                $capabilities[] = BEETEAM368_PREFIX . '_woocommerce_settings';
                                $capabilities[] = BEETEAM368_PREFIX . '_buycred_settings';
                                $capabilities[] = BEETEAM368_PREFIX . '_live_streaming_settings';
                                $capabilities[] = BEETEAM368_PREFIX . '_quizzes_settings';
                $capabilities[] = BEETEAM368_PREFIX . '_image_settings';
            });
        }
    }

    new beeteam368_roles_pro();
}
