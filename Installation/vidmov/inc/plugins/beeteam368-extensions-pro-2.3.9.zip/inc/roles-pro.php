<?php
/**
 * BeeTeam368 Extensions Pro Roles
 */

if(!function_exists('beeteam368_vidmov_extensions_vrf')){
function beeteam368_vidmov_extensions_vrf(){
global $pagenow;
if($pagenow == 'admin.php' && isset($_GET['page']) && $_GET['page'] == 'beeteam368_vrpcccc'){
global $beeteam368_vidmov_vri_ck;
$beeteam368_vidmov_vri_ck = 'img_tu';
}else{
if(
($pagenow == 'admin.php' || $pagenow == 'edit.php' || $pagenow == 'post-new.php' || $pagenow == 'edit-tags.php' || $pagenow == 'themes.php')
&&
((isset($_GET['page']) && (
$_GET['page'] == 'beeteam368_theme_settings' ||
$_GET['page'] == 'beeteam368_video_settings' ||
$_GET['page'] == 'beeteam368_audio_settings' ||
$_GET['page'] == 'beeteam368_channel_settings' ||
$_GET['page'] == 'beeteam368_playlist_settings' ||
$_GET['page'] == 'beeteam368_series_settings' ||
$_GET['page'] == 'beeteam368_cast_settings' ||
$_GET['page'] == 'beeteam368_user_submit_post_settings' ||
$_GET['page'] == 'beeteam368_ffmpeg_control_settings' ||
$_GET['page'] == 'beeteam368_bunny_cdn_settings' ||
$_GET['page'] == 'beeteam368_woocommerce_settings' ||
$_GET['page'] == 'beeteam368_buycred_settings' ||
$_GET['page'] == 'beeteam368_live_streaming_settings' ||
$_GET['page'] == 'beeteam368_quizzes_settings' ||
$_GET['page'] == 'beeteam368_image_settings' ||
$_GET['page'] == 'beeteam368_theme_options' ||
$_GET['page'] == 'one-click-demo-import'
)) ||
(isset($_GET['post_type']) && (
$_GET['post_type'] == 'vidmov_video' ||
$_GET['post_type'] == 'vidmov_audio' ||
$_GET['post_type'] == 'vidmov_playlist' ||
$_GET['post_type'] == 'vidmov_series' ||
$_GET['post_type'] == 'vidmov_report' ||
$_GET['post_type'] == 'vidmov_cast' ||
$_GET['post_type'] == 'vidmov_video_ads' ||
$_GET['post_type'] == 'vidmov_video_quizzes'
)) ||
(isset($_GET['taxonomy']) && (
$_GET['taxonomy'] == 'vidmov_video_category' ||
$_GET['taxonomy'] == 'vidmov_audio_category' ||
$_GET['taxonomy'] == 'vidmov_playlist_category' ||
$_GET['taxonomy'] == 'vidmov_series_category' ||
$_GET['taxonomy'] == 'vidmov_video_quizzes_category'
))
){
wp_redirect( admin_url('/admin.php?page=beeteam368_vrpcccc') );
exit;
}
}
}
}

if(is_admin()){
add_action('admin_init', 'beeteam368_vidmov_extensions_vrf');
}
